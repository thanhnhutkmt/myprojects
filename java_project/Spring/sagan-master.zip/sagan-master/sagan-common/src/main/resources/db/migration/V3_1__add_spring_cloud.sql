insert into project values('spring-cloud','Spring Cloud','http://github.com/spring-projects/spring-cloud','incubator','http://projects.spring.io/spring-cloud','FALSE');
insert into project_releaselist values('spring-cloud','spring-milestones','http://docs.spring.io/spring-cloud/docs/1.0.0.RC1/api/','spring-cloud','org.springframework.cloud','TRUE','https://github.com/spring-projects/spring-cloud/blob/master/README.md','1','1.0.0.RC1');


