package sagan.guides;

public interface UnderstandingMetadata extends DocumentMetadata {

    String getSubject();
}
