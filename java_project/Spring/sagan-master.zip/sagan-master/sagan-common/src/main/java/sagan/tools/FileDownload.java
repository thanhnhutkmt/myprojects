package sagan.tools;

public interface FileDownload {
    String getBucket();

    String getFile();

    String getDescription();

    String getSize();

    String getOs();
}
