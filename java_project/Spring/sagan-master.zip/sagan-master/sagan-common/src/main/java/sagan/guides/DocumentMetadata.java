package sagan.guides;

public interface DocumentMetadata {
}
