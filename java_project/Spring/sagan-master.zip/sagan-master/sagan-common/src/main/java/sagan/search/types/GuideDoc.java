package sagan.search.types;

public class GuideDoc extends SearchEntry {

    @Override
    public String getType() {
        return SearchType.GUIDE.toString();
    }
}
