package sagan.search.types;

public class SitePage extends SearchEntry {

    @Override
    public String getType() {
        return SearchType.SITE_PAGE.toString();
    }
}
