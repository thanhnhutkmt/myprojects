package sagan.search.types;

public class ProjectPage extends SearchEntry {

    @Override
    public String getType() {
        return SearchType.PROJECT_PAGE.toString();
    }
}
