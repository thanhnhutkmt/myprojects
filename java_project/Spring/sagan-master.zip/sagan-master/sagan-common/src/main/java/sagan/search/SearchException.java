package sagan.search;

@SuppressWarnings("serial")
public class SearchException extends RuntimeException {

    public SearchException(Throwable ex) {
        super(ex);
    }
}
