package sagan.search.support;

import org.jsoup.nodes.Document;

public interface DocumentProcessor {
    void process(Document document);
}
