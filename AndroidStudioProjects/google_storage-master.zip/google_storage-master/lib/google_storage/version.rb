module GoogleStorage
  VERSION = "0.2.0"
end
