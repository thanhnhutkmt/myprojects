
require 'crack'
require 'google_storage/client'

module GoogleStorage


end

