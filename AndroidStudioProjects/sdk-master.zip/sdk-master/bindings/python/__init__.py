# Get rid of the funny nested name space.
from mega import *
