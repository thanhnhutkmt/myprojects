﻿#ifndef QTMEGALISTENER_H
#define QTMEGALISTENER_H

#include <QObject>
#include "megaapi.h"

namespace mega
{
class QTMegaListener : public QObject, public MegaListener
{
	Q_OBJECT

public:
    explicit QTMegaListener(MegaApi *megaApi, MegaListener *parent=NULL);
    virtual ~QTMegaListener();

	virtual void onRequestStart(MegaApi* api, MegaRequest *request);
	virtual void onRequestFinish(MegaApi* api, MegaRequest *request, MegaError* e);
    virtual void onRequestUpdate(MegaApi* api, MegaRequest *request);
	virtual void onRequestTemporaryError(MegaApi *api, MegaRequest *request, MegaError* e);
	virtual void onTransferStart(MegaApi *api, MegaTransfer *transfer);
	virtual void onTransferFinish(MegaApi* api, MegaTransfer *transfer, MegaError* e);
	virtual void onTransferUpdate(MegaApi *api, MegaTransfer *transfer);
	virtual void onTransferTemporaryError(MegaApi *api, MegaTransfer *transfer, MegaError* e);
    virtual void onUsersUpdate(MegaApi* api, MegaUserList *users);
    virtual void onNodesUpdate(MegaApi* api, MegaNodeList *nodes);
    virtual void onAccountUpdate(MegaApi* api);
	virtual void onReloadNeeded(MegaApi* api);

#ifdef ENABLE_SYNC
    virtual void onSyncStateChanged(MegaApi *api,  MegaSync *sync);
    virtual void onSyncFileStateChanged(MegaApi *api, MegaSync *sync, const char *filePath, int newState);
    virtual void onGlobalSyncStateChanged(MegaApi* api);
#endif

protected:
    virtual void customEvent(QEvent * event);

    MegaApi *megaApi;
	MegaListener *listener;
};
}

#endif // QTMEGALISTENER_H
