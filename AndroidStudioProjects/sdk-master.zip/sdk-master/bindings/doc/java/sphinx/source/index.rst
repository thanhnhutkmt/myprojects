.. _index:

Java Bindings User Guide!
===============================

Description
------------

This user guide is for those intending to create their own application which will implement functions of the Mega API.
This Guide will run you through the basic first steps required to perform CRUD functions.

To start please select a link below - We recommend you start with the getting started guide.

Contents:

.. toctree::
   :maxdepth: 2
   
   gettingstarted
   installsdk

Search
==================
* :ref:`search`

