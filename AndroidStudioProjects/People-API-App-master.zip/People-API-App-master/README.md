This app demonstrates how to use the new People API in Android: https://developers.google.com/people/

HOW TO USE:
Configure a People API enabled project via Google API Console: 
http://blog.grafixartist.com/people-api-android-tutorial-1/
Add your project's Client ID and Client Secret in strings.xml
