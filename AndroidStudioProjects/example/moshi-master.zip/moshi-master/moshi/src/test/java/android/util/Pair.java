package android.util;

public final class Pair {
}
