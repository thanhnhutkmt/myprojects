This app demonstrates how to use the new People API in Android: https://developers.google.com/+/mobile/android/getting-started

HOW TO USE:
Configure a People API & Google+ API enabled project via Google API Console:

1) Now you need to create OAuth Client ID for Web application and Android.


2) Add your project's Web application  Client ID and Client Secret in strings.xml
